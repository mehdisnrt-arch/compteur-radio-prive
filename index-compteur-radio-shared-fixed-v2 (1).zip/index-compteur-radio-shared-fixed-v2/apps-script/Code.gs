/*******************************************************
 * Backend Google Apps Script for Index Compteur Radio
 * Version FIX: supports JSONP/GET from GitHub Pages/iPhone.
 *******************************************************/

const SHEET_NAME = 'Index';
const ADMIN_PIN = '1234'; // IMPORTANT: change this PIN if needed
const RADIOS = ['Aswat', 'Med Radio', 'Medina FM', 'Medi1', 'Cap Radio', 'Chada FM', 'HIT RADIO', 'MFM'];
const HEADERS = ['ID', 'Date', 'Radio', 'Index', 'CreatedAt', 'UpdatedAt'];

function doGet(e) {
  try {
    const p = e && e.parameter ? e.parameter : {};
    const action = String(p.action || 'ping').toLowerCase();
    let result;

    if (action === 'ping') {
      ensureSheet_();
      result = { ok: true, message: 'OK' };
    } else if (action === 'list') {
      requireAdmin_(p.pin);
      result = { ok: true, records: getRecords_() };
    } else if (action === 'last') {
      const radio = normalizeRadio_(p.radio);
      result = { ok: true, lastIndex: getLastIndex_(radio, null) };
    } else if (action === 'add') {
      result = addRecordObject_(p);
    } else if (action === 'update') {
      result = updateRecordObject_(p);
    } else if (action === 'delete') {
      result = deleteRecordObject_(p);
    } else {
      result = { ok: false, error: 'UNKNOWN_ACTION', message: 'Action inconnue.' };
    }

    return output_(result, p.callback);
  } catch (err) {
    const p = e && e.parameter ? e.parameter : {};
    return output_(errorObject_(err), p.callback);
  }
}

function doPost(e) {
  try {
    const payload = parsePayload_(e);
    const action = String(payload.action || '').toLowerCase();
    let result;

    if (action === 'add') result = addRecordObject_(payload);
    else if (action === 'update') result = updateRecordObject_(payload);
    else if (action === 'delete') result = deleteRecordObject_(payload);
    else result = { ok: false, error: 'UNKNOWN_ACTION', message: 'Action inconnue.' };

    return output_(result, payload.callback);
  } catch (err) {
    return output_(errorObject_(err), null);
  }
}

function addRecordObject_(payload) {
  const sheet = ensureSheet_();
  const date = normalizeDate_(payload.date);
  const radio = normalizeRadio_(payload.radio);
  const index = normalizeIndex_(payload.index);

  if (existsDateRadio_(date, radio, null)) {
    return { ok: false, error: 'DUPLICATE', message: 'Cette radio existe déjà pour cette date.' };
  }

  const lastIndex = getLastIndex_(radio, null);
  if (lastIndex !== null && index < lastIndex) {
    return { ok: false, error: 'INDEX_ERRONE', message: 'Index erroné' };
  }

  const now = new Date().toISOString();
  const id = Utilities.getUuid();
  sheet.appendRow([id, date, radio, index, now, '']);
  return { ok: true, record: { id: id, date: date, radio: radio, index: index, createdAt: now, updatedAt: '' } };
}

function updateRecordObject_(payload) {
  requireAdmin_(payload.pin);
  const sheet = ensureSheet_();
  const id = clean_(payload.id);
  const date = normalizeDate_(payload.date);
  const radio = normalizeRadio_(payload.radio);
  const index = normalizeIndex_(payload.index);

  const row = findRowById_(id);
  if (!row) throw makeError_('NOT_FOUND', 'Index introuvable.');

  if (existsDateRadio_(date, radio, id)) {
    return { ok: false, error: 'DUPLICATE', message: 'Cette radio existe déjà pour cette date.' };
  }

  const lastIndex = getLastIndex_(radio, id);
  if (lastIndex !== null && index < lastIndex) {
    return { ok: false, error: 'INDEX_ERRONE', message: 'Index erroné' };
  }

  const now = new Date().toISOString();
  const createdAt = sheet.getRange(row, 5).getValue();
  sheet.getRange(row, 2, 1, 5).setValues([[date, radio, index, createdAt, now]]);
  return { ok: true };
}

function deleteRecordObject_(payload) {
  requireAdmin_(payload.pin);
  const sheet = ensureSheet_();
  const id = clean_(payload.id);
  const row = findRowById_(id);
  if (!row) throw makeError_('NOT_FOUND', 'Index introuvable.');
  sheet.deleteRow(row);
  return { ok: true };
}

function ensureSheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(SHEET_NAME);
  if (!sheet) sheet = ss.insertSheet(SHEET_NAME);

  if (sheet.getLastRow() === 0) {
    sheet.appendRow(HEADERS);
  } else {
    const existing = sheet.getRange(1, 1, 1, Math.max(sheet.getLastColumn(), HEADERS.length)).getValues()[0];
    const needsHeaders = HEADERS.some(function(h, i) { return existing[i] !== h; });
    if (needsHeaders) sheet.getRange(1, 1, 1, HEADERS.length).setValues([HEADERS]);
  }

  sheet.getRange(1, 1, 1, HEADERS.length).setFontWeight('bold').setBackground('#d9ead3');
  sheet.setFrozenRows(1);
  return sheet;
}

function getRecords_() {
  const sheet = ensureSheet_();
  const lastRow = sheet.getLastRow();
  if (lastRow < 2) return [];

  const values = sheet.getRange(2, 1, lastRow - 1, HEADERS.length).getValues();
  return values
    .filter(function(row) { return row[0]; })
    .map(function(row) {
      return {
        id: String(row[0]),
        date: toIsoDate_(row[1]),
        radio: String(row[2]),
        index: Number(row[3]),
        createdAt: row[4] ? new Date(row[4]).toISOString() : '',
        updatedAt: row[5] ? new Date(row[5]).toISOString() : ''
      };
    });
}

function getLastIndex_(radio, excludeId) {
  const records = getRecords_()
    .filter(function(r) { return r.radio === radio && (!excludeId || r.id !== excludeId); })
    .sort(function(a, b) {
      const byDate = String(b.date).localeCompare(String(a.date));
      if (byDate !== 0) return byDate;
      return String(b.createdAt || '').localeCompare(String(a.createdAt || ''));
    });

  return records.length ? Number(records[0].index) : null;
}

function existsDateRadio_(date, radio, excludeId) {
  return getRecords_().some(function(r) {
    return r.date === date && r.radio === radio && (!excludeId || r.id !== excludeId);
  });
}

function findRowById_(id) {
  const sheet = ensureSheet_();
  const lastRow = sheet.getLastRow();
  if (lastRow < 2) return null;
  const ids = sheet.getRange(2, 1, lastRow - 1, 1).getValues();
  for (let i = 0; i < ids.length; i++) {
    if (String(ids[i][0]) === id) return i + 2;
  }
  return null;
}

function parsePayload_(e) {
  if (e.parameter && e.parameter.payload) return JSON.parse(e.parameter.payload);
  if (e.postData && e.postData.contents) return JSON.parse(e.postData.contents);
  return {};
}

function normalizeDate_(value) {
  const date = clean_(value);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) throw makeError_('BAD_DATE', 'Date incorrecte.');
  return date;
}

function normalizeRadio_(value) {
  const radio = clean_(value);
  if (RADIOS.indexOf(radio) === -1) throw makeError_('BAD_RADIO', 'Radio incorrecte.');
  return radio;
}

function normalizeIndex_(value) {
  const raw = clean_(value).replace(/\s+/g, '').replace(',', '.');
  if (!/^\d+(\.\d+)?$/.test(raw)) throw makeError_('BAD_INDEX', 'Index incorrect.');
  const index = Number(raw);
  if (!isFinite(index) || index < 0) throw makeError_('BAD_INDEX', 'Index incorrect.');
  return index;
}

function requireAdmin_(pin) {
  if (clean_(pin) !== ADMIN_PIN) throw makeError_('BAD_PIN', 'PIN admin incorrect.');
}

function clean_(value) {
  return String(value === undefined || value === null ? '' : value).trim();
}

function toIsoDate_(value) {
  if (Object.prototype.toString.call(value) === '[object Date]' && !isNaN(value)) {
    return Utilities.formatDate(value, Session.getScriptTimeZone(), 'yyyy-MM-dd');
  }
  return String(value).slice(0, 10);
}

function output_(obj, callback) {
  const json = JSON.stringify(obj);
  if (callback) {
    return ContentService
      .createTextOutput(String(callback).replace(/[^A-Za-z0-9_$\.]/g, '') + '(' + json + ');')
      .setMimeType(ContentService.MimeType.JAVASCRIPT);
  }
  return ContentService
    .createTextOutput(json)
    .setMimeType(ContentService.MimeType.JSON);
}

function errorObject_(err) {
  const code = err && err.code ? err.code : 'SERVER_ERROR';
  const message = err && err.message ? err.message : 'Erreur serveur.';
  return { ok: false, error: code, message: message };
}

function makeError_(code, message) {
  const err = new Error(message);
  err.code = code;
  return err;
}
