window.APP_CONFIG = {
  API_URL: "https://script.google.com/macros/s/AKfycbzNQsMFuWmL0uQ8meB8XqVUSymroeGtuuM6CXmC8629MkYYH-KV8rIGsphDI4ANH5WO4A/exec"
};
